# ReformaFácil Plugin (FastAPI)


**Actualización 2025 → 2026:**
- Precios base: **Libro 47 (2025)**
- Inflación adicional por cercanía a 2026: **+6%** (campo `inflacion_extra_2026`, por defecto 0.06). Puede ajustarse en la petición.
