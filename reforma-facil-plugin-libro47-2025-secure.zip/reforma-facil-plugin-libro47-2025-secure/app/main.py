from fastapi import FastAPI, HTTPException, Response, Header, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from typing import List, Dict, Optional
import json, os
from pathlib import Path
from .models import Partida, ItemEntrada, PresupuestoEntrada, LineaSalida, PresupuestoSalida
from .utils_pdf import generar_pdf

API_KEY = os.getenv("API_KEY", "change-me")  # Render → Environment → API_KEY

def require_api_key(x_api_key: Optional[str] = Header(None), authorization: Optional[str] = Header(None)):
    token = None
    if x_api_key:
        token = x_api_key
    elif authorization and authorization.lower().startswith("bearer "):
        token = authorization.split(" ", 1)[1].strip()
    if not token or token != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")


app = FastAPI(title="ReformaFácil", description="Calcula presupuestos de reformas según Libro 46 (demo).", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://chat.openai.com"
        # Añade tu dominio de Render cuando lo tengas, por ejemplo:
        # "https://reforma-facil.onrender.com"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

static_path = Path(__file__).parent / "static"
app.mount("/.well-known", StaticFiles(directory=static_path / ".well-known"), name="well-known")

DB_PARTIDAS: Dict[str, Partida] = {}
mock_path = Path(__file__).parent / "libro47_2025.json"
if mock_path.exists():
    data = json.loads(mock_path.read_text(encoding="utf-8"))
    for p in data:
        DB_PARTIDAS[p["codigo"]] = Partida(**p)

@app.get("/health")
def health(): return {"status":"ok"}

@app.get("/partidas", response_model=List[Partida])
def listar_partidas(q: str | None = None, _: None = Depends(require_api_key)):
    partidas = list(DB_PARTIDAS.values())
    if q:
        ql = q.lower()
        partidas = [p for p in partidas if ql in p.descripcion.lower() or ql in p.codigo.lower()]
    return partidas

@app.post("/presupuesto", response_model=PresupuestoSalida)
def calcular_presupuesto(payload: PresupuestoEntrada, _: None = Depends(require_api_key)):
    lineas: List[LineaSalida] = []
    base = 0.0
    for item in payload.items:
        if item.codigo not in DB_PARTIDAS:
            raise HTTPException(status_code=404, detail=f"Partida {item.codigo} no encontrada")
        p = DB_PARTIDAS[item.codigo]
        if item.cantidad <= 0:
            raise HTTPException(status_code=400, detail=f"Cantidad inválida para {item.codigo}")
        subtotal = round(p.precio_unitario * item.cantidad, 2)
        base += subtotal
        lineas.append(LineaSalida(codigo=p.codigo, descripcion=p.descripcion, unidad=p.unidad, cantidad=item.cantidad, precio_unitario=p.precio_unitario, subtotal=subtotal))
    bi = round(base * payload.beneficio_industrial, 2)
    gg = round(base * payload.gastos_generales, 2)
    infl = round((base + bi + gg) * (payload.inflacion + getattr(payload, 'inflacion_extra_2026', 0.06)), 2)
    base_actualizada = round(base + bi + gg + infl, 2)
    iva = round(base_actualizada * payload.iva, 2)
    total = round(base_actualizada + iva, 2)
    return PresupuestoSalida(cliente=payload.cliente, obra=payload.obra, lineas=lineas, base=round(base,2), bi=bi, gg=gg, inflacion=infl, base_actualizada=base_actualizada, iva=iva, total=total)

@app.post("/presupuesto/pdf")
def presupuesto_pdf(payload: PresupuestoEntrada, _: None = Depends(require_api_key)):
    presupuesto = calcular_presupuesto(payload)
    pdf_bytes = generar_pdf(presupuesto)
    return Response(content=pdf_bytes, media_type="application/pdf", headers={"Content-Disposition": 'attachment; filename="presupuesto.pdf"'})
