from pydantic import BaseModel, Field
from typing import List, Optional

class Partida(BaseModel):
    codigo: str = Field(..., description="Referencia Libro 46")
    descripcion: str
    unidad: str
    precio_unitario: float

class ItemEntrada(BaseModel):
    codigo: str
    cantidad: float

class PresupuestoEntrada(BaseModel):
    cliente: Optional[str] = None
    obra: Optional[str] = None
    items: List[ItemEntrada]
    beneficio_industrial: float = 0.20
    gastos_generales: float = 0.10
    inflacion: float = 0.00
    inflacion_extra_2026: float = 0.06
    iva: float = 0.21

class LineaSalida(BaseModel):
    codigo: str
    descripcion: str
    unidad: str
    cantidad: float
    precio_unitario: float
    subtotal: float

class PresupuestoSalida(BaseModel):
    cliente: Optional[str]
    obra: Optional[str]
    lineas: List[LineaSalida]
    base: float
    bi: float
    gg: float
    inflacion: float
    base_actualizada: float
    iva: float
    total: float
