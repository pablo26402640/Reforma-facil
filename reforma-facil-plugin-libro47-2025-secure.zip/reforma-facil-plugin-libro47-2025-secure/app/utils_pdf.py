from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.lib.utils import ImageReader
from typing import List
import io
from pathlib import Path
from .models import PresupuestoSalida, LineaSalida

EMPRESA = "Pablo de Benedetti - Construcciones y Reformas"
DIRECCION = "Capdepera (Mallorca)"
TELEFONO = "+34 630 168 523"
CONDICIONES_PAGO = "50% al inicio · 30% al 70% de avance · 20% al finalizar"
LOGO_PATH = Path(__file__).parent / "static" / ".well-known" / "logo.png"

def _draw_header(c, obra:str, cliente:str):
    y = 286*mm
    # Logo
    if LOGO_PATH.exists():
        try:
            img = ImageReader(str(LOGO_PATH))
            c.drawImage(img, 20*mm, y-18*mm, width=30*mm, height=18*mm, preserveAspectRatio=True, mask='auto')
        except Exception:
            pass
    # Datos empresa
    c.setFont("Helvetica-Bold", 13)
    c.drawString(55*mm, y-6*mm, EMPRESA)
    c.setFont("Helvetica", 9)
    c.drawString(55*mm, y-11*mm, f"{DIRECCION} · {TELEFONO}")
    c.drawString(55*mm, y-16*mm, f"Obra: {obra or '-'}  |  Cliente: {cliente or '-'}")

def _draw_table(c, lineas:List[LineaSalida], y_start=262*mm):
    c.setFont("Helvetica-Bold", 9)
    headers = ["Código", "Descripción", "Ud.", "Cant.", "P.Unit", "Subtotal"]
    widths = [20*mm, 85*mm, 12*mm, 15*mm, 25*mm, 25*mm]
    x = 20*mm; y = y_start
    for i, h in enumerate(headers):
        c.drawString(x, y, h); x += widths[i]
    y -= 6*mm
    c.setLineWidth(0.3); c.line(20*mm, y, 20*mm + sum(widths), y)
    c.setFont("Helvetica", 9)
    y -= 4*mm
    for ln in lineas:
        if y < 40*mm:
            c.showPage(); y = 280*mm
        x = 20*mm
        cells = [ln.codigo, ln.descripcion, ln.unidad, f"{ln.cantidad:.2f}", f"{ln.precio_unitario:.2f} €", f"{ln.subtotal:.2f} €"]
        for i, cell in enumerate(cells):
            c.drawString(x, y, str(cell)[:70]); x += widths[i]
        y -= 6*mm
    return y

def _draw_totals(c, p:PresupuestoSalida, y):
    if y < 60*mm:
        c.showPage(); y = 280*mm
    c.setFont("Helvetica-Bold", 10)
    items = [("Base", p.base),("Beneficio Industrial", p.bi),("Gastos Generales", p.gg),("Inflación", p.inflacion),("Base actualizada", p.base_actualizada),("IVA", p.iva),("TOTAL", p.total)]
    x_label = 130*mm; x_value = 180*mm
    for label, value in items:
        c.drawRightString(x_label, y, label + ":")
        c.drawRightString(x_value, y, f"{value:.2f} €"); y -= 6*mm
    y -= 4*mm
    c.setFont("Helvetica", 9)
    c.drawString(20*mm, y, f"Condiciones de pago: {CONDICIONES_PAGO}")

def generar_pdf(p:PresupuestoSalida) -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    _draw_header(c, p.obra or "-", p.cliente or "-")
    y = _draw_table(c, p.lineas)
    _draw_totals(c, p, y - 4*mm)
    c.showPage(); c.save(); buf.seek(0); return buf.read()
